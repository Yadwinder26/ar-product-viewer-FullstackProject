Backend repo link- https://github.com/Yashraturi70/ar-product-viewer-backend
I was not able to upload backend and frontend in same repo because 2 team member worked on frontend and deployed it on vercel and 2 worked on backend and deployed it in railway and in railway it directly starts deployment and no option to select backend folder inside the repo is there so hence different repo.


live url-https://ar-product-viewer-frontend.vercel.app/
